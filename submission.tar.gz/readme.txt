By: Griffin Dominguez

The Legend of Zelda themed GBA game.
Press Start to begin game.
Collect rupees until you reach 21.
Once you collect 21 rupees Hyrule is saved!
Beware of the bomb or you will succumb to Ganon and lose the game.

Controls:
Left - Move left
Right - Move Right
Up - Move Up
Down - Move Down
Select - Restart Game