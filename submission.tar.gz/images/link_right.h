/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 link_right link_right.png 
 * Time-stamp: Sunday 07/12/2020, 20:47:18
 * 
 * Image Information
 * -----------------
 * link_right.png 10@27
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LINK_RIGHT_H
#define LINK_RIGHT_H

extern const unsigned short link_right[270];
#define LINK_RIGHT_SIZE 540
#define LINK_RIGHT_LENGTH 270
#define LINK_RIGHT_WIDTH 10
#define LINK_RIGHT_HEIGHT 27

#endif

