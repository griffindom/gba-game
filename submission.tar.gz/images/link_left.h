/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 link_left link_left.png 
 * Time-stamp: Sunday 07/12/2020, 20:47:08
 * 
 * Image Information
 * -----------------
 * link_left.png 10@27
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LINK_LEFT_H
#define LINK_LEFT_H

extern const unsigned short link_left[270];
#define LINK_LEFT_SIZE 540
#define LINK_LEFT_LENGTH 270
#define LINK_LEFT_WIDTH 10
#define LINK_LEFT_HEIGHT 27

#endif

