/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 bomb bomb.png 
 * Time-stamp: Sunday 07/12/2020, 20:17:13
 * 
 * Image Information
 * -----------------
 * bomb.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOMB_H
#define BOMB_H

extern const unsigned short bomb[256];
#define BOMB_SIZE 512
#define BOMB_LENGTH 256
#define BOMB_WIDTH 16
#define BOMB_HEIGHT 16

#endif

