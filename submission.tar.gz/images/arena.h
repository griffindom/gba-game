/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 arena arena.png 
 * Time-stamp: Saturday 07/11/2020, 00:10:09
 * 
 * Image Information
 * -----------------
 * arena.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ARENA_H
#define ARENA_H

extern const unsigned short arena[38400];
#define ARENA_SIZE 76800
#define ARENA_LENGTH 38400
#define ARENA_WIDTH 240
#define ARENA_HEIGHT 160

#endif

