/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 small_rupee small_rupee.png 
 * Time-stamp: Saturday 07/11/2020, 00:10:34
 * 
 * Image Information
 * -----------------
 * small_rupee.png 5@9
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SMALL_RUPEE_H
#define SMALL_RUPEE_H

extern const unsigned short small_rupee[45];
#define SMALL_RUPEE_SIZE 90
#define SMALL_RUPEE_LENGTH 45
#define SMALL_RUPEE_WIDTH 5
#define SMALL_RUPEE_HEIGHT 9

#endif

