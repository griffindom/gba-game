/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 grass host/HW/hw8/images/grass.jpg --resize=160x240 
 * Time-stamp: Thursday 07/09/2020, 06:53:52
 * 
 * Image Information
 * -----------------
 * host/HW/hw8/images/grass.jpg 160@240
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GRASS_H
#define GRASS_H

extern const unsigned short grass[38400];
#define GRASS_SIZE 76800
#define GRASS_LENGTH 38400
#define GRASS_WIDTH 160
#define GRASS_HEIGHT 240

#endif

