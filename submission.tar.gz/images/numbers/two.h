/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 two two.png 
 * Time-stamp: Sunday 07/12/2020, 18:03:31
 * 
 * Image Information
 * -----------------
 * two.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TWO_H
#define TWO_H

extern const unsigned short two[70];
#define TWO_SIZE 140
#define TWO_LENGTH 70
#define TWO_WIDTH 7
#define TWO_HEIGHT 10

#endif

