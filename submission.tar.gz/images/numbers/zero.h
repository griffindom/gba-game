/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 zero zero.png 
 * Time-stamp: Sunday 07/12/2020, 18:03:05
 * 
 * Image Information
 * -----------------
 * zero.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ZERO_H
#define ZERO_H

extern const unsigned short zero[70];
#define ZERO_SIZE 140
#define ZERO_LENGTH 70
#define ZERO_WIDTH 7
#define ZERO_HEIGHT 10

#endif

