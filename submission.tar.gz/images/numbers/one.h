/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 one one.png 
 * Time-stamp: Sunday 07/12/2020, 18:03:17
 * 
 * Image Information
 * -----------------
 * one.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ONE_H
#define ONE_H

extern const unsigned short one[70];
#define ONE_SIZE 140
#define ONE_LENGTH 70
#define ONE_WIDTH 7
#define ONE_HEIGHT 10

#endif

