/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 nine nine.png 
 * Time-stamp: Sunday 07/12/2020, 18:06:52
 * 
 * Image Information
 * -----------------
 * nine.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NINE_H
#define NINE_H

extern const unsigned short nine[70];
#define NINE_SIZE 140
#define NINE_LENGTH 70
#define NINE_WIDTH 7
#define NINE_HEIGHT 10

#endif

