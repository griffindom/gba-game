/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 six six.png 
 * Time-stamp: Sunday 07/12/2020, 18:05:02
 * 
 * Image Information
 * -----------------
 * six.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SIX_H
#define SIX_H

extern const unsigned short six[70];
#define SIX_SIZE 140
#define SIX_LENGTH 70
#define SIX_WIDTH 7
#define SIX_HEIGHT 10

#endif

