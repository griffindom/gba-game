/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 four four.png 
 * Time-stamp: Sunday 07/12/2020, 18:04:01
 * 
 * Image Information
 * -----------------
 * four.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FOUR_H
#define FOUR_H

extern const unsigned short four[70];
#define FOUR_SIZE 140
#define FOUR_LENGTH 70
#define FOUR_WIDTH 7
#define FOUR_HEIGHT 10

#endif

