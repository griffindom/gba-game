/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 three three.png 
 * Time-stamp: Sunday 07/12/2020, 18:03:43
 * 
 * Image Information
 * -----------------
 * three.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef THREE_H
#define THREE_H

extern const unsigned short three[70];
#define THREE_SIZE 140
#define THREE_LENGTH 70
#define THREE_WIDTH 7
#define THREE_HEIGHT 10

#endif

