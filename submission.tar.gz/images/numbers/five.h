/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 five five.png 
 * Time-stamp: Sunday 07/12/2020, 18:04:16
 * 
 * Image Information
 * -----------------
 * five.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIVE_H
#define FIVE_H

extern const unsigned short five[70];
#define FIVE_SIZE 140
#define FIVE_LENGTH 70
#define FIVE_WIDTH 7
#define FIVE_HEIGHT 10

#endif

