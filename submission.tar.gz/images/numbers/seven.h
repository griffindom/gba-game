/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 seven seven.png 
 * Time-stamp: Sunday 07/12/2020, 18:06:33
 * 
 * Image Information
 * -----------------
 * seven.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SEVEN_H
#define SEVEN_H

extern const unsigned short seven[70];
#define SEVEN_SIZE 140
#define SEVEN_LENGTH 70
#define SEVEN_WIDTH 7
#define SEVEN_HEIGHT 10

#endif

