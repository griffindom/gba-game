/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --device=gba --mode=3 eight eight.png 
 * Time-stamp: Sunday 07/12/2020, 18:06:43
 * 
 * Image Information
 * -----------------
 * eight.png 7@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EIGHT_H
#define EIGHT_H

extern const unsigned short eight[70];
#define EIGHT_SIZE 140
#define EIGHT_LENGTH 70
#define EIGHT_WIDTH 7
#define EIGHT_HEIGHT 10

#endif

